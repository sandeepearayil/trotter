import pandas as pd
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score, confusion_matrix

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC



def add_one(number):
    return number + 1


def recipes():
    return {'LogisticRegression': 'v 0.0.1', 'DecisionTreeClassifier': 'v 0.0.1', 'RandomForestClassifier': 'v 0.0.1', 'SVC': 'v 0.0.1'}


@pd.api.extensions.register_dataframe_accessor("trotml")
class MLAlgorithms:
    def __init__(self, pandas_obj):
        self._validate(pandas_obj)
        self._obj = pandas_obj

    @staticmethod
    def _validate(obj):
        # verify there is a column target_variable
        if "target_variable" not in obj.columns :
            raise AttributeError("Must have 'target_variable'.")

    @property
    def classification(self):
        # build a classification model
        lat = self._obj.target_variable
        lon = self._obj.target_variable
        return (float(lon.mean()), float(lat.mean()))


class Model:
    def __init__(self):
        pass

    def instance(self,model_name):

        if model_name == "LogisticRegression":
            model = LogisticRegression()
        elif  model_name == "DecisionTreeClassifier":
            model = DecisionTreeClassifier()
        elif  model_name == "RandomForestClassifier":
            model =RandomForestClassifier()
        elif  model_name == "SVC":
            model = SVC()

        return model