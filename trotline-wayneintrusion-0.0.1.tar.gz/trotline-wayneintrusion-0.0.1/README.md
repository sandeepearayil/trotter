# Trotter ML Ops Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.


How to build this package

py -m build

py -m pip install ./dist/trotline-wayneintrusion-0.0.1.tar.gz


Reference
1. https://packaging.python.org/en/latest/tutorials/packaging-projects/
2. https://packaging.python.org/en/latest/tutorials/installing-packages/